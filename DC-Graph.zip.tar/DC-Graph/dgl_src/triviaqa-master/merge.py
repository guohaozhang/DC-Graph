import json
from transformers import AutoTokenizer, AutoModelForTokenClassification
from transformers import pipeline

with open('../../OUTPUT_DIR/prediction.json', 'r') as reader:
    nothing_data = json.load(reader)
with open('../../OUTPUT_DIR/wikipedia_prediction.json', 'r') as reader:
    new_data = json.load(reader)

tokenizer = AutoTokenizer.from_pretrained("dslim/bert-base-NER")
model = AutoModelForTokenClassification.from_pretrained("dslim/bert-base-NER")
nlp = pipeline("ner", model=model, tokenizer=tokenizer)

replaced = []
for qid in nothing_data.keys():
    example = nothing_data[qid]
    ner_results = nlp(example)
    if ner_results:
        continue
    else:
        new_example = new_data[qid]
        new_ner_result = nlp(new_example)
        if new_ner_result:
            continue
        else:
            nothing_data[qid] = new_data[qid]
            replaced.append(qid)

fp = open('/home/zgh/Desktop/BERT_nothing/OUTPUT_DIR/replace_prediction.json', mode='w')
fp.write(json.dumps(nothing_data, indent=4) + "\n")
fp.close()

fp = open('/home/zgh/Desktop/BERT_nothing/qid_replaced.json', mode='w')
fp.write(json.dumps(replaced, indent=4) + "\n")
fp.close()
