import json
from collections import Counter
import string
import re
import sys


class TriviaExample(object):
    def __init__(self,
                 qas_id,
                 question_text,
                 ):
        self.qas_id = qas_id
        self.question_text = question_text


def read_trivia_examples(input_file, is_training=True):
    with open(input_file, "r", encoding='utf-8') as reader:
        input_data = json.load(reader)['data']

    examples = []
    for entry in input_data:
        for paragraph in entry['paragraphs']:
            for qa in paragraph['qas']:
                qas_id = qa['qid']
                question_text = qa['question']

                example = TriviaExample(
                    qas_id=qas_id,
                    question_text=question_text,
                )
                examples.append(example)
    return examples


def get_file_contents(filename, encoding='utf-8'):
    with open(filename, encoding=encoding) as f:
        content = f.read()
    return content


def read_json(filename, encoding='utf-8'):
    contents = get_file_contents(filename, encoding=encoding)
    return json.loads(contents)


def read_clean_part(datum):
    for key in ['EntityPages', 'SearchResults']:
        new_page_list = []
        for page in datum.get(key, []):
            if page['DocPartOfVerifiedEval']:
                new_page_list.append(page)
        datum[key] = new_page_list
    assert len(datum['EntityPages']) + len(datum['SearchResults']) > 0
    return datum


def read_triviaqa_data(qajson):
    data = read_json(qajson)
    # read only documents and questions that are a part of clean data set
    if data['VerifiedEval']:
        clean_data = []
        for datum in data['Data']:
            if datum['QuestionPartOfVerifiedEval']:
                if data['Domain'] == 'Web':
                    datum = read_clean_part(datum)
                clean_data.append(datum)
        data['Data'] = clean_data
    return data


def get_question_doc_string(qid, doc_name):
    return '{}--{}'.format(qid, doc_name)


def get_qd_to_answer(data):
    key_to_answer = {}
    for datum in data['Data']:
        for page in datum.get('EntityPages', []) + datum.get('SearchResults', []):
            qd_tuple = get_question_doc_string(datum['QuestionId'], page['Filename'])
            key_to_answer[qd_tuple] = datum['Answer']
    return key_to_answer


def get_key_to_ground_truth(data):
    if data['Domain'] == 'Wikipedia':
        return {datum['QuestionId']: datum['Answer'] for datum in data['Data']}
    else:
        return get_qd_to_answer(data)


def normalize_answer(s):
    """Lower text and remove punctuation, articles and extra whitespace."""

    def remove_articles(text):
        return re.sub(r'\b(a|an|the)\b', ' ', text)

    def white_space_fix(text):
        return ' '.join(text.split())

    def handle_punc(text):
        exclude = set(string.punctuation + "".join([u"‘", u"’", u"´", u"`"]))
        return ''.join(ch if ch not in exclude else ' ' for ch in text)

    def lower(text):
        return text.lower()

    def replace_underscore(text):
        return text.replace('_', ' ')

    return white_space_fix(remove_articles(handle_punc(lower(replace_underscore(s))))).strip()


def get_ground_truths(answer):
    return answer['NormalizedAliases'] + [normalize_answer(ans) for ans in answer.get('HumanAnswers', [])]


def exact_match_score(prediction, ground_truth):
    return normalize_answer(prediction) == normalize_answer(ground_truth)


def metric_max_over_ground_truths(metric_fn, prediction, ground_truths):
    scores_for_ground_truths = []
    for ground_truth in ground_truths:
        score = metric_fn(prediction, ground_truth)
        scores_for_ground_truths.append(score)
    return max(scores_for_ground_truths)


def f1_score(prediction, ground_truth):
    prediction_tokens = normalize_answer(prediction).split()
    ground_truth_tokens = normalize_answer(ground_truth).split()
    common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return 0
    precision = 1.0 * num_same / len(prediction_tokens)
    recall = 1.0 * num_same / len(ground_truth_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1


def evaluate_triviaqa(ground_truth, predicted_answers, qid_list=None, mute=False):
    f1 = exact_match = common = 0
    if qid_list is None:
        qid_list = ground_truth.keys()
    for qid in qid_list:
        if qid not in predicted_answers:
            if not mute:
                message = 'Missed question {} will receive score 0.'.format(qid)
                print(message, file=sys.stderr)
            continue
        if qid not in ground_truth:
            if not mute:
                message = 'Irrelavant question {} will receive score 0.'.format(qid)
                print(message, file=sys.stderr)
            continue
        common += 1
        prediction = predicted_answers[qid]
        ground_truths = get_ground_truths(ground_truth[qid])
        em_for_this_question = metric_max_over_ground_truths(
            exact_match_score, prediction, ground_truths)
        if em_for_this_question == 0 and not mute:
            print("em=0:", prediction, ground_truths)
        exact_match += em_for_this_question
        f1_for_this_question = metric_max_over_ground_truths(
            f1_score, prediction, ground_truths)
        f1 += f1_for_this_question

    exact_match = 100.0 * exact_match / len(qid_list)
    f1 = 100.0 * f1 / len(qid_list)

    return {'exact_match': exact_match, 'f1': f1, 'common': common, 'denominator': len(qid_list),
            'pred_len': len(predicted_answers), 'gold_len': len(ground_truth)}


# dataset_file = './samples/triviaqa_sample.json'
# prediction_file = './samples/sample_predictions.json'

dataset_file = '../../DATA_DIR/qa/wikipedia-dev.json'
# prediction_file = '../../OUTPUT_DIR/num+person_class_pinjie_train.json'
prediction_file = '../../OUTPUT_DIR/location_result/location_25_test_new_dict_merge.json'

dataset_json = read_triviaqa_data(dataset_file)
key_to_ground_truth = get_key_to_ground_truth(dataset_json)
# print(key_to_ground_truth)
print(len(key_to_ground_truth))

predictions = read_json(prediction_file)
# print(predictions)

qid_list = key_to_ground_truth.keys()
# print(qid_list)

# fp = open('/home/zgh/Desktop/BERT_nothing/src/triviaqa-master/first_step.json', mode='w')
fp = open('/home/zgh/Desktop/BERT_nothing/src/new_result.json', mode='w')
# result = []
result = {}
for qid in qid_list:
    if qid not in predictions:
        continue
    if qid not in key_to_ground_truth:
        continue
    prediction = predictions[qid]
    ground_truths = get_ground_truths(key_to_ground_truth[qid])
    # print(prediction)
    print(ground_truths)

    em_for_this_question = metric_max_over_ground_truths(
        exact_match_score, prediction, ground_truths)
    # print(em_for_this_question)
    # print('------------------------------------------------------')

    # temp_dict = {"Qid": qid, "Predict Answer": prediction,
    #              "NormalizedAliases": ground_truths, "Is_True": em_for_this_question}
    # result.append(temp_dict)
    result[qid] = [em_for_this_question, prediction, ground_truths]

fp.write(json.dumps(result, indent=4) + "\n")
fp.close()
