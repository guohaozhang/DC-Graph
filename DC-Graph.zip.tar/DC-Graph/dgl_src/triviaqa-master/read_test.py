import json

with open('./test.json', 'r') as reader:
    data = json.load(reader)

print(data[0]['Is_True']==True)