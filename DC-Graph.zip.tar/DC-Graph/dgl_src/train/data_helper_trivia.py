"""
data_helper_trivia_class.py
 - helper functions to process trivia dataset
"""
"""
data_helper_trivia_class.py
 - helper functions to process trivia dataset
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import collections
import logging
import json
import math
import os
import random
import pickle
from tqdm import tqdm, trange
import spacy
import textacy
import pandas as pd
import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader, RandomSampler, SequentialSampler
from torch.utils.data.distributed import DistributedSampler
from transformers.tokenization_bert import whitespace_tokenize, BasicTokenizer, BertTokenizer
from qa_util import _improve_answer_span, _get_best_indexes, get_final_text
from transformers import AutoTokenizer, AutoModelForTokenClassification
from transformers import pipeline
from stanfordcorenlp import StanfordCoreNLP

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

os.environ['JAVA_HOME'] = '/dev/shm/jdk-20.0.1'
nlp = StanfordCoreNLP(r'/dev/shm/stanford-corenlp-4.5.4')


class TriviaExample(object):
    def __init__(self,
                 qas_id,
                 question_text,
                 doc_tokens,
                 orig_answer_text=None,
                 start_position=None,
                 end_position=None,
                 question_x=None,
                 question_edge_index=None,
                 question_edge_attr=None,
                 doc_x=None,
                 doc_edge_index=None,
                 doc_edge_attr=None):
        self.qas_id = qas_id
        self.question_text = question_text
        self.doc_tokens = doc_tokens
        self.orig_answer_text = orig_answer_text
        self.start_position = start_position
        self.end_position = end_position
        self.question_x = question_x
        self.question_edge_index = question_edge_index
        self.question_edge_attr = question_edge_attr
        self.doc_x = doc_x
        self.doc_edge_index = doc_edge_index
        self.doc_edge_attr = doc_edge_attr


class ExampleFeature(object):
    def __init__(self,
                 example_index,
                 query_tokens,
                 doc_tokens,
                 tok_to_orig_map,
                 start_position=None,
                 end_position=None):
        self.example_index = example_index
        self.query_tokens = query_tokens
        self.doc_tokens = doc_tokens
        self.tok_to_orig_map = tok_to_orig_map
        self.start_position = start_position
        self.end_position = end_position


def ner(text):
    output = nlp.annotate(text, properties={
        'annotators': 'ner',
        'outputFormat': 'json'
    })
    output = json.loads(output)

    return output


def question_is_person(question):
    ner_pos_result = ner(question)
    tokens_question = []
    pos_question = []
    entity_question = []

    for preitem in ner_pos_result['sentences']:
        for item in preitem['tokens']:
            # tokens_question.append(item['originalText'])
            tokens_question.append(item['lemma'])
            pos_question.append(item['pos'])

            if item['ner'] == "O":
                entity_question.append(None)
            else:
                entity_question.append(item['ner'])

    new_question = tokens_question[0]
    for item in tokens_question[1:]:
        new_question = new_question + ' ' + item

    vb_pass_entity = ['VB', 'VBD', 'VBG', 'VBN', 'VBZ', '.', ',']
    who = ['who', 'whom', 'whose']
    w = ['WDT', 'WP', 'WP$', 'WRB']
    is_person = False

    ## 1 case
    if 'which' in tokens_question and 'TITLE' in entity_question:
        for i in range(len(tokens_question)):
            if tokens_question[i] == 'which':
                for j in range(i + 1, len(tokens_question)):
                    if pos_question[j] in vb_pass_entity:
                        break
                    if entity_question[j] == 'TITLE':
                        is_person = True
                        break
            if is_person:
                break
    ## 2 case
    if 'what' in tokens_question and 'TITLE' in entity_question and not is_person:
        for i in range(len(tokens_question)):
            if tokens_question[i] == 'what':
                for j in range(i + 1, len(tokens_question)):
                    if pos_question[j] in vb_pass_entity:
                        break
                    if entity_question[j] == 'TITLE':
                        is_person = True
                        break
            if is_person:
                break

    ## 3 case
    if 'what be the' in new_question and 'name of' in new_question and \
            ('TITLE' in entity_question or 'PERSON' in entity_question) and not is_person:
        what_position = 0
        name_position = 0
        for i in range(len(tokens_question) - 2):
            if tokens_question[i] == 'what':
                if tokens_question[i + 1] == 'be' and tokens_question[i + 2] == 'the':
                    what_position = i + 2
            if tokens_question[i] == 'name':
                if tokens_question[i + 1] == 'of':
                    name_position = i

        if 0 < name_position - what_position < 3:
            if 'TITLE' in entity_question[name_position:] or 'PERSON' in entity_question[name_position:]:
                for item in entity_question[name_position:]:
                    if item in vb_pass_entity:
                        break
                    if item == 'TITLE' or item == 'PERSON':
                        is_person = True
                        break

    ## 4 case
    if 'what be' in new_question and 'name' in new_question and 'POS' in pos_question and 'PERSON' in entity_question and not is_person:
        is_person = True

    ## 5 case
    if ('what be the nickname of' in new_question or 'what be the surname of' in new_question) and not is_person:
        is_person = True

    ## 6 case
    if 'know by what name' in new_question and (
            'TITLE' in entity_question or 'PERSON' in entity_question) and not is_person:
        is_person = True

    ## 7 case
    if 'what name be' in new_question and 'know' in tokens_question and \
            ('TITLE' in entity_question or 'PERSON' in entity_question) and not is_person:
        is_person = True

    ## 8 case
    if 'how be' in new_question and 'know' in tokens_question and 'PERSON' in entity_question and not is_person:
        how_position = 0
        know_position = 0
        for i in range(len(tokens_question) - 1):
            if tokens_question[i] == 'how':
                if tokens_question[i + 1] == 'be':
                    how_position = i + 1
            if tokens_question[i] == 'know':
                know_position = i

        if how_position < know_position:
            if 'PERSON' in entity_question[how_position + 1: know_position]:
                is_person = True
            for item in pos_question[how_position + 1: know_position]:
                if item in vb_pass_entity:
                    is_person = False
                    break

    ## 9 case
    if 'whose' in tokens_question and not is_person:
        is_person = True
        for i in range(len(tokens_question)):
            if pos_question[i] in w:
                if tokens_question[i] not in who:
                    is_person = False
                    break

        first_word = ''
        for item in tokens_question:
            if 'a' <= item[0] <= 'z':
                first_word = item
                break
        if first_word == 'whose':
            is_person = True

    ## 10 case
    if 'whom' in tokens_question and not is_person:
        is_person = True
        for i in range(len(tokens_question)):
            if pos_question[i] in w:
                if tokens_question[i] not in who:
                    is_person = False
                    break

        first_word = ''
        for item in tokens_question:
            if 'a' <= item[0] <= 'z':
                first_word = item
                break
        if first_word == 'whom':
            is_person = True

    ## 11 case
    if 'who' in tokens_question and not is_person:
        print('------------------------')
        is_person = True
        for i in range(len(tokens_question)):
            if pos_question[i] in w:
                if tokens_question[i] not in who:
                    is_person = False
                    break

        first_word = ''
        for item in tokens_question:
            if 'a' <= item[0] <= 'z':
                first_word = item
                break
        if first_word == 'who':
            is_person = True

        if '.' in pos_question[:-2]:
            for i in range(len(tokens_question) - 2):
                if pos_question[i] == '.':
                    first_word = tokens_question[i + 1]
                    break
        if first_word == 'who':
            is_person = True

    ## 12 case
    if 'name the' in new_question and 'TITLE' in entity_question and not is_person:
        name_position = 0
        title_position = 0
        for i in range(len(tokens_question) - 1):
            if tokens_question[i] == 'name':
                if tokens_question[i + 1] == 'the':
                    name_position = i + 1
                    break

        for i in range(name_position, len(tokens_question)):
            if entity_question[i] == 'TITLE':
                title_position = i
                break
        if title_position != 0:
            is_person = True
            for i in range(name_position, title_position):
                if pos_question[i] in vb_pass_entity:
                    is_person = False
                    break

    return is_person


def read_trivia_examples(input_file, is_training=True):
    ################################################################
    spacy_nlp = spacy.load('en_core_web_sm')
    spacy_nlp.add_pipe("merge_entities")
    spacy_nlp.add_pipe("merge_noun_chunks")

    def create_graph(sentences, spacy_nlp):
        dic = {"entity": [], "relation": [], "object": [], 'entity vector': [], 'relation vector': [],
               'object vector': []}
        token_nlp = spacy.load('en_core_web_sm')
        for n, sentence in enumerate(sentences):
            has_extracted = False
            lst_generators = list(textacy.extract.subject_verb_object_triples(sentence))
            for sent in lst_generators:
                subj = " ".join(map(str, sent.subject))
                obj = " ".join(map(str, sent.object))
                relation = " ".join(map(str, sent.verb))
                if len(sent.object) >= 4:
                    temp_doc = spacy_nlp(obj)
                    is_verb = 0
                    verb_obj = ''
                    want_what = []
                    for token in temp_doc:
                        if token.dep_ == 'ROOT':
                            if token.pos_ == 'NOUN':
                                obj = token.text
                            elif token.pos_ == 'VERB':
                                is_verb = 1
                                verb_obj = token.text
                                want_what = [str(child) for child in token.children]
                                break
                    if is_verb == 1:
                        for token in temp_doc:
                            if token.text in want_what and token.pos_ in ['NOUN', 'PRON', 'PROPN']:
                                verb_obj = verb_obj + ' ' + token.text
                                if [str(child) for child in token.children] == []:
                                    break
                                else:
                                    for child_token in [str(child) for child in token.children]:
                                        want_what.append(child_token)
                        obj = verb_obj

                obj_list = obj.split(' ')
                if len(obj_list) >= 4:
                    continue

                ##将文本转换为向量
                token_list = [str(token.text) for token in sentence]
                new_sentence = ' '.join(token_list)
                new_doc = token_nlp(new_sentence)
                if subj in token_list:
                    for token in sentence:
                        if str(token.text) == subj:
                            subj_vector = token.vector_norm
                            break
                else:
                    subj_doc = token_nlp(subj)
                    subj_list = [str(token.text) for token in subj_doc]
                    subj_len = len(subj_list)
                    subj_vector = 0
                    for token in sentence:
                        if str(token.text) in subj_list:
                            subj_vector += token.vector_norm
                            subj_len -= 1
                        if subj_len == 0:
                            break
                    subj_vector = round(subj_vector / len(subj_list), 6)

                if obj in token_list:
                    for token in sentence:
                        if str(token.text) == obj:
                            obj_vector = token.vector_norm
                            break
                else:
                    obj_doc = token_nlp(obj)
                    obj_list = [str(token.text) for token in obj_doc]
                    obj_len = len(obj_list)
                    obj_vector = 0
                    for token in sentence:
                        if str(token.text) in obj_list:
                            obj_vector += token.vector_norm
                            obj_len -= 1
                        if obj_len == 0:
                            break
                    obj_vector = round(obj_vector / len(obj_list), 6)

                if relation in token_list:
                    for token in sentence:
                        if str(token.text) == relation:
                            relation_vector = token.vector_norm
                            break
                else:
                    relation_doc = token_nlp(relation)
                    relation_list = [str(token.text) for token in relation_doc]
                    relation_len = len(relation_list)
                    relation_vector = 0
                    for token in sentence:
                        if str(token.text) in relation_list:
                            relation_vector += token.vector_norm
                            relation_len -= 1
                        if relation_len == 0:
                            break
                    relation_vector = round(relation_vector / len(relation_list), 6)

                dic["entity"].append(subj)
                dic["object"].append(obj)
                dic["relation"].append(relation)
                dic["entity vector"].append(subj_vector)
                dic["object vector"].append(obj_vector)
                dic["relation vector"].append(relation_vector)
                has_extracted = True
            if not has_extracted:
                has_relation = False
                for word in sentence:
                    if word.dep_ == 'ROOT' and word.pos_ in ['AUX', 'VERB']:
                        relation_word = word
                        has_relation = True
                if has_relation:
                    has_entity = False
                    has_object = False
                    for word in sentence:
                        if word.text in [str(child) for child in relation_word.children]:
                            if not has_object and word.pos_ in ['NOUN', 'PRON', 'PROPN'] and word.dep_ in ['attr',
                                                                                                           'dobj']:
                                object_word = word
                                has_object = True
                            elif not has_entity and word.pos_ in ['NOUN', 'PRON', 'PROPN']:
                                entity_word = word
                                has_entity = True
                    if has_entity and has_object:
                        dic["entity"].append(str(entity_word.text))
                        dic["object"].append(str(object_word.text))
                        dic["relation"].append(str(relation_word.text))
                        dic["entity vector"].append(entity_word.vector_norm)
                        dic["object vector"].append(object_word.vector_norm)
                        dic["relation vector"].append(relation_word.vector_norm)
        dtf = pd.DataFrame(dic)
        return dtf

    def add_graph(sentences, dtf):
        add_relations = dtf.values.tolist()
        raw_dtf_len = len(dtf.values.tolist())

        for sent in sentences:
            for i in range(len(sent)):
                if sent[i].ent_type_ != '' and sent[i].text not in list(dtf['entity']) and sent[i].text not in list(
                        dtf['object']):
                    ## 同位语，宾语补足语的情况
                    if sent[i].dep_ in ['oprd', 'appos']:
                        for j in range(i - 1, -1, -1):
                            if sent[j].dep_ in ['pobj', 'dobj']:
                                add_relations.append([sent[j].text, 'has relations with', sent[i].text,
                                                      sent[j].vector_norm,
                                                      round((sent[j].vector_norm + sent[i].vector_norm) / 2, 6),
                                                      sent[i].vector_norm])
                                if sent[j].text not in list(dtf['entity']) and sent[j].text not in list(dtf['object']):
                                    temp_relation = sent[j]
                                    temp_entity = sent[j]
                                    for k in range(j - 1, -1, -1):
                                        if sent[k].text == sent[j].head.text and sent[k].pos_ not in ['NOUN', 'PRON',
                                                                                                      'PROPN']:
                                            temp_relation = sent[k]
                                            break
                                    for k in range(j - 1, -1, -1):
                                        if sent[k].text == temp_relation.head.text and sent[k].pos_ in ['NOUN', 'PRON',
                                                                                                        'PROPN']:
                                            temp_entity = sent[k]
                                            break
                                    if temp_entity == sent[j]:
                                        temp_head = temp_relation.head
                                        it_child = [str(child) for child in temp_head.children]
                                        for k in range(j - 1, -1, -1):
                                            if sent[k].text in it_child and sent[k].pos_ in ['NOUN', 'PRON', 'PROPN']:
                                                temp_entity = sent[k]
                                                break
                                    if temp_entity != sent[j]:
                                        add_relations.append([temp_entity.text, temp_relation.text, sent[j].text,
                                                              temp_entity.vector_norm, temp_relation.vector_norm,
                                                              sent[j].vector_norm])
                                break
                    ##介词宾语的情况
                    elif sent[i].dep_ == 'pobj':
                        temp_prep = sent[i].head
                        add_len = len(add_relations)
                        for j in range(i - 1, -1, -1):
                            if sent[j].text == temp_prep.head.text and sent[j].pos_ == 'VERB':
                                temp_relation = str(sent[j].text) + ' ' + str(temp_prep.text)
                                temp_relation_vector = round((sent[j].vector_norm + temp_prep.vector_norm) / 2, 6)
                                for k in range(j - 1, -1, -1):
                                    if sent[k].pos_ in ['NOUN', 'PRON', 'PROPN'] and sent[k].text in [str(child) for
                                                                                                      child
                                                                                                      in
                                                                                                      sent[j].children]:
                                        add_relations.append([sent[k].text, temp_relation, sent[i].text,
                                                              sent[k].vector_norm, temp_relation_vector,
                                                              sent[i].vector_norm])
                                        break
                                break
                        if add_len == len(add_relations):
                            for j in range(len(sent)):
                                if sent[j].text == temp_prep.head.text and sent[j].pos_ == 'VERB':
                                    temp_relation = str(sent[j].text) + ' ' + str(temp_prep.text)
                                    temp_relation_vector = round((sent[j].vector_norm + temp_prep.vector_norm) / 2, 6)
                                    for k in range(j - 1, -1, -1):
                                        if sent[k].pos_ in ['NOUN', 'PRON', 'PROPN'] and sent[k].text in [str(child) for
                                                                                                          child in
                                                                                                          sent[
                                                                                                              j].children]:
                                            add_relations.append([sent[k].text, temp_relation, sent[i].text,
                                                                  sent[k].vector_norm, temp_relation_vector,
                                                                  sent[i].vector_norm])
                                            break
                                    break
                    ##并列的情况
                    elif sent[i].dep_ == 'conj':
                        temp_head_text = sent[i].head.text
                        for j in range(i - 1, -1, -1):
                            if sent[j].text == temp_head_text:
                                if sent[j].dep_ == 'conj':
                                    temp_head_text = sent[j].head.text
                                else:
                                    for item in add_relations:
                                        if sent[j].text == item[0]:
                                            add_relations.append(
                                                [sent[i].text, item[1], item[2], sent[i].vector_norm, item[4], item[5]])
                                            break
                                        elif sent[j].text == item[2]:
                                            add_relations.append(
                                                [item[0], item[1], sent[i].text, item[3], item[4], sent[i].vector_norm])
                                            break
                    else:
                        if sent[i].head.pos_ in ['NOUN', 'PRON', 'PROPN']:
                            continue
                        temp_relation = sent[i].head
                        if temp_relation.head.pos_ in ['NOUN', 'PRON', 'PROPN']:
                            temp_entity = temp_relation.head
                            add_relations.append([temp_entity.text, temp_relation.text, sent[i].text,
                                                  temp_entity.vector_norm, temp_relation.vector_norm,
                                                  sent[i].vector_norm])

        for item in add_relations[raw_dtf_len:]:
            dtf.loc[len(dtf)] = item
        return dtf

    def change_question(doc, text):
        answer = 'unknown'
        ##第一种情况
        want_word_1 = ['Which', 'which', 'What', 'what']
        want_word_2 = ['How Many', 'How many', 'how many']
        want_word_3 = ['When', 'when', 'Where', 'where']
        is_changed = False
        start_position = 0
        end_position = 0
        new_question = ''
        ##第二种情况
        for item in want_word_2:
            if item in text:
                for i in range(len(doc)):
                    if item in str(doc[i].text):
                        temp_question = ''
                        for word in str(doc[i].text).split(' '):
                            if word in ['How', 'how']:
                                temp_question = temp_question + ' ' + answer
                            elif word in ['Many', 'many']:
                                continue
                            else:
                                temp_question = temp_question + ' ' + word
                        if temp_question[0] == ' ':
                            temp_question = temp_question[1:]
                        new_question = new_question + ' ' + temp_question
                    elif str(doc[i].text) == '?':
                        new_question = new_question + ' .'
                        continue
                    else:
                        new_question = new_question + ' ' + str(doc[i].text)
                new_question = new_question[1:]
                is_changed = True
                break

        ##第一种情况
        if not is_changed:
            for item in want_word_1:
                if item in text:
                    for i in range(len(doc)):
                        split_token = str(doc[i].text).split(' ')
                        start_position = i
                        if item in split_token:
                            for j in range(i, len(doc)):
                                if doc[j].pos_ in ['AUX', 'VERB']:
                                    end_position = j - 1
                                    is_changed = True
                                    break
                        if is_changed:
                            break
                if is_changed:
                    break
            if is_changed:
                for i in range(len(doc)):
                    if start_position <= i < end_position:
                        continue
                    if i == end_position:
                        new_question = new_question + ' ' + answer
                        continue
                    if str(doc[i].text) == '?':
                        new_question = new_question + ' .'
                        continue
                    new_question = new_question + ' ' + str(doc[i].text)
            new_question = new_question[1:]

            ##第三种情况
        if not is_changed:
            for item in want_word_3:
                if item in text:
                    for i in range(len(doc)):
                        if str(doc[i].text) in want_word_3:
                            new_question = new_question + ' ' + answer
                            is_changed = True
                        elif str(doc[i].text) == '?':
                            new_question = new_question + ' .'
                            continue
                        else:
                            new_question = new_question + ' ' + str(doc[i].text)
                    if is_changed:
                        new_question = new_question[1:]
                        break
                    else:
                        new_question = ''

        ##第四种情况
        if not is_changed:
            add_position = 0
            for i in range(len(doc) - 1):
                if doc[i].pos_ == 'ADP' and doc[i + 1].text == '?':
                    add_position = i
                    is_changed = True
                    break
            if is_changed:
                for i in range(len(doc)):
                    if str(doc[i].text) == '?':
                        new_question = new_question + ' .'
                        continue
                    new_question = new_question + ' ' + str(doc[i].text)
                    if add_position == i:
                        new_question = new_question + ' ' + answer
                new_question = new_question[1:]
        return new_question

    ################################################################
    pos_tokenizer = AutoTokenizer.from_pretrained('vblagoje/bert-english-uncased-finetuned-pos')
    pos_model = AutoModelForTokenClassification.from_pretrained(
        'vblagoje/bert-english-uncased-finetuned-pos')
    pos = pipeline('ner', tokenizer=pos_tokenizer, model=pos_model)

    path = '/dev/shm/BERT_nothing/s_include_org_train_test_and_12_test/'
    per_dict_a = [line.strip() for line in open(path + 'a.txt', encoding='utf-8')]
    per_dict_b = [line.strip() for line in open(path + 'b.txt', encoding='utf-8')]
    per_dict_c = [line.strip() for line in open(path + 'c.txt', encoding='utf-8')]
    per_dict_d = [line.strip() for line in open(path + 'd.txt', encoding='utf-8')]
    per_dict_e = [line.strip() for line in open(path + 'e.txt', encoding='utf-8')]
    per_dict_f = [line.strip() for line in open(path + 'f.txt', encoding='utf-8')]
    per_dict_g = [line.strip() for line in open(path + 'g.txt', encoding='utf-8')]
    per_dict_h = [line.strip() for line in open(path + 'h.txt', encoding='utf-8')]
    per_dict_i = [line.strip() for line in open(path + 'i.txt', encoding='utf-8')]
    per_dict_j = [line.strip() for line in open(path + 'j.txt', encoding='utf-8')]
    per_dict_k = [line.strip() for line in open(path + 'k.txt', encoding='utf-8')]
    per_dict_l = [line.strip() for line in open(path + 'l.txt', encoding='utf-8')]
    per_dict_m = [line.strip() for line in open(path + 'm.txt', encoding='utf-8')]
    per_dict_n = [line.strip() for line in open(path + 'n.txt', encoding='utf-8')]
    per_dict_o = [line.strip() for line in open(path + 'o.txt', encoding='utf-8')]
    per_dict_p = [line.strip() for line in open(path + 'p.txt', encoding='utf-8')]
    per_dict_q = [line.strip() for line in open(path + 'q.txt', encoding='utf-8')]
    per_dict_r = [line.strip() for line in open(path + 'r.txt', encoding='utf-8')]
    per_dict_s = [line.strip() for line in open(path + 's.txt', encoding='utf-8')]
    per_dict_t = [line.strip() for line in open(path + 't.txt', encoding='utf-8')]
    per_dict_u = [line.strip() for line in open(path + 'u.txt', encoding='utf-8')]
    per_dict_v = [line.strip() for line in open(path + 'v.txt', encoding='utf-8')]
    per_dict_w = [line.strip() for line in open(path + 'w.txt', encoding='utf-8')]
    per_dict_x = [line.strip() for line in open(path + 'x.txt', encoding='utf-8')]
    per_dict_y = [line.strip() for line in open(path + 'y.txt', encoding='utf-8')]
    per_dict_z = [line.strip() for line in open(path + 'z.txt', encoding='utf-8')]

    def sentence_has_person(sentence):
        is_person = False
        words = sentence.split(' ')
        for item in words:
            temp_word = item
            # temp_word = str.capitalize(item)
            if temp_word == '':
                continue
            if not is_person and temp_word[0] == 'A' and temp_word in per_dict_a:
                is_person = True
            elif not is_person and temp_word[0] == 'B' and temp_word in per_dict_b:
                is_person = True
            elif not is_person and temp_word[0] == 'C' and temp_word in per_dict_c:
                is_person = True
            elif not is_person and temp_word[0] == 'D' and temp_word in per_dict_d:
                is_person = True
            elif not is_person and temp_word[0] == 'E' and temp_word in per_dict_e:
                is_person = True
            elif not is_person and temp_word[0] == 'F' and temp_word in per_dict_f:
                is_person = True
            elif not is_person and temp_word[0] == 'G' and temp_word in per_dict_g:
                is_person = True
            elif not is_person and temp_word[0] == 'H' and temp_word in per_dict_h:
                is_person = True
            elif not is_person and temp_word[0] == 'I' and temp_word in per_dict_i:
                is_person = True
            elif not is_person and temp_word[0] == 'J' and temp_word in per_dict_j:
                is_person = True
            elif not is_person and temp_word[0] == 'K' and temp_word in per_dict_k:
                is_person = True
            elif not is_person and temp_word[0] == 'L' and temp_word in per_dict_l:
                is_person = True
            elif not is_person and temp_word[0] == 'M' and temp_word in per_dict_m:
                is_person = True
            elif not is_person and temp_word[0] == 'N' and temp_word in per_dict_n:
                is_person = True
            elif not is_person and temp_word[0] == 'O' and temp_word in per_dict_o:
                is_person = True
            elif not is_person and temp_word[0] == 'P' and temp_word in per_dict_p:
                is_person = True
            elif not is_person and temp_word[0] == 'Q' and temp_word in per_dict_q:
                is_person = True
            elif not is_person and temp_word[0] == 'R' and temp_word in per_dict_r:
                is_person = True
            elif not is_person and temp_word[0] == 'S' and temp_word in per_dict_s:
                is_person = True
            elif not is_person and temp_word[0] == 'T' and temp_word in per_dict_t:
                is_person = True
            elif not is_person and temp_word[0] == 'U' and temp_word in per_dict_u:
                is_person = True
            elif not is_person and temp_word[0] == 'V' and temp_word in per_dict_v:
                is_person = True
            elif not is_person and temp_word[0] == 'W' and temp_word in per_dict_w:
                is_person = True
            elif not is_person and temp_word[0] == 'X' and temp_word in per_dict_x:
                is_person = True
            elif not is_person and temp_word[0] == 'Y' and temp_word in per_dict_y:
                is_person = True
            elif not is_person and temp_word[0] == 'Z' and temp_word in per_dict_z:
                is_person = True

            if is_person:
                break

        # if not is_person and len(words) > 1:
        #     for item in words[1:]:
        #         if 'A' <= item[0] <= 'Z':
        #             is_person = True
        #             break

        return is_person

    ################################################################

    total_cnt = 0
    with open(input_file, "r", encoding='utf-8') as reader:
        input_data = json.load(reader)['data']

    def is_whitespace(c):
        if c == " " or c == "\t" or c == "\r" or c == "\n" or ord(c) == 0x202F:
            return True
        return False

    examples = []
    no_answer_cnt = 0
    for entry in input_data:
        for paragraph in entry["paragraphs"]:
            paragraph_text = paragraph["context"]
            doc_tokens = []
            char_to_word_offset = []
            prev_is_whitespace = True
            for c in paragraph_text:
                if is_whitespace(c):
                    prev_is_whitespace = True
                else:
                    if prev_is_whitespace:
                        doc_tokens.append(c)
                    else:
                        doc_tokens[-1] += c
                    prev_is_whitespace = False
                char_to_word_offset.append(len(doc_tokens) - 1)

            for qa in paragraph["qas"]:
                qas_id = qa["qid"]
                question_text = qa["question"]
                start_position = None
                end_position = None
                orig_answer_text = None
                if qa["answers"] == []:
                    no_answer_cnt += 1
                    continue

                ###########################################################################
                question_doc = spacy_nlp(question_text)
                new_question = change_question(question_doc, question_text)
                question_doc = spacy_nlp(new_question)
                question_sentences = [sent for sent in question_doc.sents]
                question_dtf = create_graph(question_sentences, spacy_nlp)
                question_dtf = add_graph(question_sentences, question_dtf)
                question_dtf_list = question_dtf.values.tolist()
                question_count_list = []
                question_count_list_vector = []
                question_node_index = {}
                question_x = []
                question_edge_index = [[], []]
                question_edge_attr = []
                for item in question_dtf_list:
                    if item[0] not in question_count_list:
                        question_count_list.append(item[0])
                        question_count_list_vector.append(item[3])
                    else:
                        for i in range(len(question_count_list)):
                            if question_count_list[i] == item[0]:
                                question_count_list_vector[i] = round((question_count_list_vector[i] + item[3]) / 2, 6)
                                break
                    if item[2] not in question_count_list:
                        question_count_list.append(item[2])
                        question_count_list_vector.append(item[5])
                    else:
                        for i in range(len(question_count_list)):
                            if question_count_list[i] == item[2]:
                                question_count_list_vector[i] = round((question_count_list_vector[i] + item[5]) / 2, 6)
                                break
                for n, node in enumerate(question_count_list):
                    question_node_index[node] = n
                for item in question_count_list_vector:
                    question_x.append([item])
                for item in question_dtf_list:
                    question_edge_index[0].append(question_node_index[item[0]])
                    question_edge_index[1].append(question_node_index[item[2]])
                    question_edge_attr.append([item[4]])

                ###########################################################################

                if is_training:
                    answer = qa["answers"][0]
                    orig_answer_text = answer["text"]
                    answer_offset = answer["answer_start"]
                    answer_length = len(orig_answer_text)
                    # word position
                    start_position = char_to_word_offset[answer_offset]
                    end_position = char_to_word_offset[answer_offset + answer_length - 1]
                    actual_text = " ".join(doc_tokens[start_position:(end_position + 1)])
                    cleaned_answer_text = " ".join(
                        whitespace_tokenize(orig_answer_text))
                    cleaned_start = actual_text.lower().find(cleaned_answer_text)
                    # if actual_text.find(cleaned_answer_text) == -1:
                    if cleaned_start == -1:
                        logger.warning("Could not find answer: '%s' vs. '%s'",
                                       actual_text, cleaned_answer_text)
                        continue
                    else:
                        # cleaned_answer_text might be lower cased, needs to be reconstructued from actual_text
                        orig_answer_text = actual_text[cleaned_start:cleaned_start + len(cleaned_answer_text)]

                    ###########################################################################

                    is_person = False
                    is_num = False
                    split_answer = orig_answer_text.split(' ')
                    first_answer_word = split_answer[0]
                    str.capitalize(first_answer_word)
                    if len(split_answer) > 4:
                        is_person = False
                    else:
                        is_person = sentence_has_person(first_answer_word)

                    if True:
                        pos_result = pos(orig_answer_text)
                        for item in pos_result:
                            if item['entity'] == 'NUM':
                                is_num = True
                                break
                        if len(orig_answer_text) <= 2:
                            is_not = False
                            for item in orig_answer_text:
                                if item < '0' or item > '9':
                                    is_not = True
                                    break
                            if not is_not:
                                is_num = True

                    if is_num:
                        sentence_list = []
                        sentence_start = [0]
                        count = 0

                        data = paragraph["context"]
                        while True:
                            position = -1
                            if data.find('.') != -1 and data.find('?') != -1:
                                if data.find('.') < data.find('?'):
                                    position = data.find('.')
                                elif data.find('?') < data.find('.'):
                                    position = data.find('?')
                            elif data.find('.') != -1:
                                position = data.find('.')
                            elif data.find('?') != -1:
                                position = data.find('?')

                            if position == -1:
                                break
                            temp_sentence = data[:position + 1]
                            count += len(temp_sentence)
                            sentence_list.append(temp_sentence)
                            sentence_start.append(count)
                            data = data[position + 1:]
                        if data:
                            temp_sentence = data
                            count += len(temp_sentence)
                            sentence_list.append(temp_sentence)
                            sentence_start.append(count)

                        final_doc = ''
                        answer_position = 0
                        if is_num:
                            for i in range(len(sentence_list)):
                                have_num = False
                                num = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
                                for item in num:
                                    if item in sentence_list[i]:
                                        have_num = True
                                if not have_num:
                                    temp_result = pos(sentence_list[i])
                                    for item in temp_result:
                                        if item['entity'] == 'NUM':
                                            have_num = True
                                            break
                                if sentence_start[i] <= answer_offset <= sentence_start[i + 1]:
                                    answer_position = answer_offset - sentence_start[i] + len(final_doc)
                                    final_doc += sentence_list[i]
                                elif have_num:
                                    final_doc += sentence_list[i]

                        paragraph_text = final_doc
                        doc_tokens = []
                        char_to_word_offset = []
                        prev_is_whitespace = True
                        for c in paragraph_text:
                            if is_whitespace(c):
                                prev_is_whitespace = True
                            else:
                                if prev_is_whitespace:
                                    doc_tokens.append(c)
                                else:
                                    doc_tokens[-1] += c
                                prev_is_whitespace = False
                            char_to_word_offset.append(len(doc_tokens) - 1)

                        answer = qa["answers"][0]
                        orig_answer_text = answer["text"]
                        answer_offset = answer_position
                        answer_length = len(orig_answer_text)
                        # word position
                        start_position = char_to_word_offset[answer_offset]
                        end_position = char_to_word_offset[answer_offset + answer_length - 1]
                        actual_text = " ".join(doc_tokens[start_position:(end_position + 1)])
                        cleaned_answer_text = " ".join(
                            whitespace_tokenize(orig_answer_text))
                        cleaned_start = actual_text.lower().find(cleaned_answer_text)
                        # if actual_text.find(cleaned_answer_text) == -1:
                        if cleaned_start == -1:
                            logger.warning("Could not find answer: '%s' vs. '%s'",
                                           actual_text, cleaned_answer_text)
                            continue
                        else:
                            # cleaned_answer_text might be lower cased, needs to be reconstructued from actual_text
                            orig_answer_text = actual_text[cleaned_start:cleaned_start + len(cleaned_answer_text)]

                    if is_num:
                        question_text = 'Class Number . ' + question_text
                    else:
                        question_text = 'Class Others . ' + question_text

                    ###########################################################################

                    doc = spacy_nlp(paragraph_text)
                    sentences_doc = [sent for sent in doc.sents]
                    doc_dtf = create_graph(sentences_doc, spacy_nlp)
                    doc_dtf = add_graph(sentences_doc, doc_dtf)
                    doc_dtf_list = doc_dtf.values.tolist()
                    doc_count_list = []
                    doc_count_list_vector = []
                    doc_node_index = {}
                    doc_x = []
                    doc_edge_index = [[], []]
                    doc_edge_attr = []
                    for item in doc_dtf_list:
                        if item[0] not in doc_count_list:
                            doc_count_list.append(item[0])
                            doc_count_list_vector.append(item[3])
                        else:
                            for i in range(len(doc_count_list)):
                                if doc_count_list[i] == item[0]:
                                    doc_count_list_vector[i] = round((doc_count_list_vector[i] + item[3]) / 2, 6)
                                    break
                        if item[2] not in doc_count_list:
                            doc_count_list.append(item[2])
                            doc_count_list_vector.append(item[5])
                        else:
                            for i in range(len(doc_count_list)):
                                if doc_count_list[i] == item[2]:
                                    doc_count_list_vector[i] = round((doc_count_list_vector[i] + item[5]) / 2, 6)
                                    break
                    for n, node in enumerate(doc_count_list):
                        doc_node_index[node] = n
                    for item in doc_count_list_vector:
                        doc_x.append([item])
                    for item in doc_dtf_list:
                        doc_edge_index[0].append(doc_node_index[item[0]])
                        doc_edge_index[1].append(doc_node_index[item[2]])
                        doc_edge_attr.append([item[4]])

                    ###########################################################################

                else:
                    start_position = -1
                    end_position = -1
                    orig_answer_text = ""

                    ###########################################################################

                    num_list = ['How many', 'how many', 'When', 'Name the year', 'name the year', 'What year',
                                'what year',
                                'Which Year', 'which year', 'Which number', 'which number', 'What number',
                                'what number', 'Which century',
                                'which century', 'How old', 'how old']
                    num_list_2 = [['What is the', 'what is the'], 'number']
                    num_list_3 = [['Which', 'which'], 'year']

                    is_num = False
                    is_person = False

                    for item in num_list:
                        if item in question_text:
                            is_num = True
                            break
                    if (num_list_2[0][0] in question_text and num_list_2[1] in question_text and
                        question_text.index(num_list_2[0][0]) < question_text.index(num_list_2[1])) or \
                            (num_list_2[0][1] in question_text and num_list_2[1] in question_text and
                             question_text.index(num_list_2[0][1]) < question_text.index(num_list_2[1])):
                        is_num = True

                    if is_num:
                        sentence_list = []
                        sentence_start = [0]
                        count = 0

                        data = paragraph["context"]
                        while True:
                            position = -1
                            if data.find('.') != -1 and data.find('?') != -1:
                                if data.find('.') < data.find('?'):
                                    position = data.find('.')
                                elif data.find('?') < data.find('.'):
                                    position = data.find('?')
                            elif data.find('.') != -1:
                                position = data.find('.')
                            elif data.find('?') != -1:
                                position = data.find('?')

                            if position == -1:
                                break
                            print(data[position])
                            temp_sentence = data[:position + 1]
                            count += len(temp_sentence)
                            sentence_list.append(temp_sentence)
                            sentence_start.append(count)
                            data = data[position + 1:]
                        if data:
                            temp_sentence = data
                            count += len(temp_sentence)
                            sentence_list.append(temp_sentence)
                            sentence_start.append(count)

                        final_doc = ''

                        if is_num:
                            for i in range(len(sentence_list)):
                                have_num = False
                                num = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
                                for item in num:
                                    if item in sentence_list[i]:
                                        have_num = True
                                if not have_num:
                                    temp_result = pos(sentence_list[i])
                                    for item in temp_result:
                                        if item['entity'] == 'NUM':
                                            have_num = True
                                            break
                                # have_person = sentence_has_person(sentence_list[i])
                                if have_num:
                                    final_doc += sentence_list[i]

                        paragraph_text = final_doc
                        doc_tokens = []
                        char_to_word_offset = []
                        prev_is_whitespace = True
                        for c in paragraph_text:
                            if is_whitespace(c):
                                prev_is_whitespace = True
                            else:
                                if prev_is_whitespace:
                                    doc_tokens.append(c)
                                else:
                                    doc_tokens[-1] += c
                                prev_is_whitespace = False
                            char_to_word_offset.append(len(doc_tokens) - 1)

                    if is_num:
                        question_text = 'Class Number . ' + question_text
                    else:
                        question_text = 'Class Others . ' + question_text

                    ###########################################################################

                    doc = spacy_nlp(paragraph_text)
                    sentences_doc = [sent for sent in doc.sents]
                    doc_dtf = create_graph(sentences_doc, spacy_nlp)
                    doc_dtf = add_graph(sentences_doc, doc_dtf)
                    doc_dtf_list = doc_dtf.values.tolist()
                    doc_count_list = []
                    doc_count_list_vector = []
                    doc_node_index = {}
                    doc_x = []
                    doc_edge_index = [[], []]
                    doc_edge_attr = []
                    for item in doc_dtf_list:
                        if item[0] not in doc_count_list:
                            doc_count_list.append(item[0])
                            doc_count_list_vector.append(item[3])
                        else:
                            for i in range(len(doc_count_list)):
                                if doc_count_list[i] == item[0]:
                                    doc_count_list_vector[i] = round((doc_count_list_vector[i] + item[3]) / 2, 6)
                                    break
                        if item[2] not in doc_count_list:
                            doc_count_list.append(item[2])
                            doc_count_list_vector.append(item[5])
                        else:
                            for i in range(len(doc_count_list)):
                                if doc_count_list[i] == item[2]:
                                    doc_count_list_vector[i] = round((doc_count_list_vector[i] + item[5]) / 2, 6)
                                    break
                    for n, node in enumerate(doc_count_list):
                        doc_node_index[node] = n
                    for item in doc_count_list_vector:
                        doc_x.append([item])
                    for item in doc_dtf_list:
                        doc_edge_index[0].append(doc_node_index[item[0]])
                        doc_edge_index[1].append(doc_node_index[item[2]])
                        doc_edge_attr.append([item[4]])

                    ###########################################################################

                example = TriviaExample(
                    qas_id=qas_id,
                    question_text=question_text,
                    doc_tokens=doc_tokens,
                    orig_answer_text=orig_answer_text,
                    start_position=start_position,
                    end_position=end_position,
                    question_x=question_x,
                    question_edge_index=question_edge_index,
                    question_edge_attr=question_edge_attr,
                    doc_x=doc_x,
                    doc_edge_index=doc_edge_index,
                    doc_edge_attr=doc_edge_attr)
                examples.append(example)
                total_cnt += 1
                print(total_cnt)

    print("# of questions without an answer".format(no_answer_cnt))
    return examples


def convert_examples_to_features(examples, tokenizer, max_query_length, is_training):
    features = []
    for (example_index, example) in enumerate(examples):
        query_tokens = tokenizer.tokenize(example.question_text)
        if len(query_tokens) > max_query_length:
            query_tokens = query_tokens[:max_query_length]

        # mapping between orig and tok
        tok_to_orig_index = []
        tok_to_orig_map = {}
        orig_to_tok_index = []
        all_doc_tokens = []
        for (i, token) in enumerate(example.doc_tokens):
            orig_to_tok_index.append(len(all_doc_tokens))
            sub_tokens = tokenizer.tokenize(token)
            for sub_token in sub_tokens:
                tok_to_orig_map[len(all_doc_tokens)] = i
                tok_to_orig_index.append(i)
                all_doc_tokens.append(sub_token)

        tok_start_position = None
        tok_end_position = None
        if is_training:
            tok_start_position = orig_to_tok_index[example.start_position]
            if example.end_position < len(example.doc_tokens) - 1:
                tok_end_position = orig_to_tok_index[example.end_position + 1] - 1
            else:
                tok_end_position = len(all_doc_tokens) - 1
            (tok_start_position, tok_end_position) = _improve_answer_span(
                all_doc_tokens, tok_start_position, tok_end_position, tokenizer,
                example.orig_answer_text)

        if example_index >= 16 and example_index < 20:
            logger.info("*** Example ***")
            logger.info("example_index: %s" % (example_index))
            logger.info("tokens: %s" % " ".join(all_doc_tokens))
            if is_training:
                answer_text = " ".join(all_doc_tokens[tok_start_position:(tok_end_position + 1)])
                logger.info("start_position: %d" % (tok_start_position))
                logger.info("end_position: %d" % (tok_end_position))
                logger.info("orig answer: %s" % (example.orig_answer_text))
                logger.info("answer: %s" % (answer_text))

        features.append(
            ExampleFeature(
                example_index=example_index,
                query_tokens=query_tokens,
                doc_tokens=all_doc_tokens,
                tok_to_orig_map=tok_to_orig_map,
                start_position=tok_start_position,
                end_position=tok_end_position))
    return features


RawResult = collections.namedtuple("RawResult", \
                                   ["example_index", "stop_logits", \
                                    "start_logits", "end_logits", "id_to_tok_map"])


def make_predictions(all_examples, all_features, all_results, n_best_size, \
                     max_answer_length, do_lower_case, \
                     verbose_logging, validate_flag=True):
    assert len(all_examples) == len(all_features)

    example_index_to_results = collections.defaultdict(list)
    for result in all_results:
        example_index_to_results[result.example_index].append(result)

    _PrelimPrediction = collections.namedtuple(
        "PrelimPrediction",
        ["result_index", "start_index", "end_index", "text", "logprob"])

    validate_predictions = dict()
    all_predictions = collections.OrderedDict()
    all_nbest_json = []
    for (example_index, feature) in enumerate(all_features):
        example = all_examples[example_index]
        results = example_index_to_results[example_index]
        prelim_predictions = []
        for result_index, result in enumerate(results):
            # stop_logprob = np.log(result.stop_prob)
            # yes_no_flag_logprobs = np.log(_compute_softmax(result.yes_no_flag_logits)) # (2,)
            # yes_no_ans_logprobs = np.log(_compute_softmax(result.yes_no_ans_logits)) # (2,)

            start_indexes = _get_best_indexes(result.start_logits, n_best_size)
            end_indexes = _get_best_indexes(result.end_logits, n_best_size)
            # start_logprobs = np.log(_compute_softmax(result.start_logits))
            # end_logprobs = np.log(_compute_softmax(result.end_logits))

            for start_index in start_indexes:
                for end_index in end_indexes:
                    if start_index not in result.id_to_tok_map:
                        continue
                    if end_index not in result.id_to_tok_map:
                        continue
                    if end_index < start_index:
                        continue
                    length = end_index - start_index + 1
                    if length > max_answer_length:
                        continue
                    # logprob = stop_logprob + yes_no_flag_logprobs[0] + \
                    #          start_logprobs[start_index] + end_logprobs[end_index]
                    logprob = result.stop_logits[1] + result.start_logits[start_index] + \
                              result.end_logits[end_index]
                    prelim_predictions.append(
                        _PrelimPrediction(
                            result_index=result_index,
                            start_index=start_index,
                            end_index=end_index,
                            text=None,
                            logprob=logprob))
        prelim_predictions = sorted(
            prelim_predictions,
            key=lambda x: x.logprob,
            reverse=True)

        _NbestPrediction = collections.namedtuple("NbestPrediction", ["text", "logprob"])

        seen_predictions = {}
        nbest = []
        for pred in prelim_predictions:
            if len(nbest) >= n_best_size:
                break
            result = results[pred.result_index]
            if (pred.start_index == -1 or pred.end_index == -1):
                final_text = pred.text
            else:
                # answer_tokens: tokenized answers
                doc_start = result.id_to_tok_map[pred.start_index]
                doc_end = result.id_to_tok_map[pred.end_index]
                answer_tokens = feature.doc_tokens[doc_start:doc_end + 1]
                answer_text = " ".join(answer_tokens)
                # De-tokenize WordPieces that have been split off.
                answer_text = answer_text.replace(" ##", "")
                answer_text = answer_text.replace("##", "")
                # Clean whitespace
                answer_text = answer_text.strip()
                answer_text = " ".join(answer_text.split())

                # orig_answer_tokens: original answers
                orig_doc_start = feature.tok_to_orig_map[doc_start]
                orig_doc_end = feature.tok_to_orig_map[doc_end]
                orig_answer_tokens = example.doc_tokens[orig_doc_start:orig_doc_end + 1]
                orig_answer_text = " ".join(orig_answer_tokens)

                # combine tokenized answer text and original text
                final_text = get_final_text(answer_text, orig_answer_text, do_lower_case, verbose_logging)

            if final_text in seen_predictions:
                continue
            seen_predictions[final_text] = True
            nbest.append(
                _NbestPrediction(
                    text=final_text,
                    logprob=pred.logprob))
            if validate_flag:
                break

        if not nbest:
            nbest.append(
                _NbestPrediction(text="empty", logprob=0.0))

        assert len(nbest) >= 1

        if validate_flag:
            validate_predictions[example.qas_id] = nbest[0].text
        else:
            total_scores = []
            for entry in nbest:
                total_scores.append(entry.logprob)

            nbest_json = []
            for (i, entry) in enumerate(nbest):
                output = collections.OrderedDict()
                output["text"] = entry.text
                output["logprob"] = entry.logprob
                nbest_json.append(output)

            assert len(nbest_json) >= 1

            # cur_prediction = collections.OrderedDict()
            # cur_prediction["qid"] = example.qas_id
            # cur_prediction["answer"] = nbest_json[0]["text"]
            # all_predictions.append(cur_prediction)
            all_predictions[example.qas_id] = nbest_json[0]["text"]

            cur_nbest_json = collections.OrderedDict()
            cur_nbest_json["qid"] = example.qas_id
            cur_nbest_json["answers"] = nbest_json
            all_nbest_json.append(cur_nbest_json)

    if validate_flag:
        return validate_predictions
    else:
        return all_predictions, all_nbest_json


def write_predictions(all_examples, all_features, all_results, n_best_size, \
                      max_answer_length, do_lower_case, \
                      output_prediction_file, output_nbest_file, verbose_logging):
    """Write final predictions to the json file."""
    logger.info("Writing predictions to: %s" % (output_prediction_file))
    logger.info("Writing nbest to: %s" % (output_nbest_file))

    all_predictions, all_nbest_json = make_predictions(all_examples, all_features, \
                                                       all_results, n_best_size, \
                                                       max_answer_length, do_lower_case, \
                                                       verbose_logging, validate_flag=False)

    with open(output_prediction_file, "w") as writer:
        writer.write(json.dumps(all_predictions, indent=4) + "\n")

    with open(output_nbest_file, "w") as writer:
        writer.write(json.dumps(all_nbest_json, indent=4) + "\n")
