from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import logging
import json
import math
import os
import random
import pickle
from tqdm import tqdm, trange
from tqdm.contrib import tzip
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader, RandomSampler, SequentialSampler
import collections

from transformers.tokenization_bert import whitespace_tokenize, BasicTokenizer, BertTokenizer
from transformers.file_utils import PYTORCH_PRETRAINED_BERT_CACHE

from modeling_BERT import BertQA
from qa_util import split_train_dev_data
from chunk_helper_trivia import convert_examples_to_features, RawResult, make_predictions
from eval_triviaqa import TriviaEvaluator
from qa_util import split_train_dev_data, gen_model_features, _improve_answer_span, \
    get_final_text, _compute_softmax, _get_best_indexes
from data_helper_trivia import read_trivia_examples
import dgl
from dgl.dataloading import GraphDataLoader

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S',
                    level=logging.INFO)
logger = logging.getLogger(__name__)


def validate_model(model, tokenizer, dev_examples, dev_features,
                   dev_dataloader, dev_evaluator, best_dev_score, device, dev_question_loader, dev_doc_loader):
    all_results = []
    for text, question, doc in tzip(dev_dataloader, dev_question_loader, dev_doc_loader):
        input_ids = text[0].to(device)
        input_mask = text[1].to(device)
        segment_ids = text[2].to(device)
        example_indices = text[3]
        question_features = text[4].to(device)
        doc_features = text[5].to(device)
        batch_question_g = question.to(device)
        batch_doc_g = doc.to(device)
        with torch.no_grad():
            batch_start_logits, batch_end_logits = model(input_ids=input_ids, token_type_ids=segment_ids,
                                                         attention_mask=input_mask, question_g=batch_question_g,
                                                         doc_g=batch_doc_g, question_features=question_features,
                                                         doc_features=doc_features)
        for i, example_index in enumerate(example_indices):
            start_logits = batch_start_logits[i].detach().cpu().tolist()
            end_logits = batch_end_logits[i].detach().cpu().tolist()
            dev_feature = dev_features[example_index.item()]
            unique_id = int(dev_feature.unique_id)
            all_results.append(RawResult(unique_id=unique_id,
                                         start_logits=start_logits,
                                         end_logits=end_logits))
    dev_predictions = make_predictions(dev_examples, dev_features, all_results,
                                       n_best_size=2, max_answer_length=60, do_lower_case=True,
                                       verbose_logging=False, validate_flag=True)
    print(dev_predictions)

    dev_scores = dev_evaluator.evaluate_triviaqa(dev_predictions)
    dev_score = dev_scores['f1']
    logger.info('dev score: {}'.format(dev_score))

    output_prediction_file = os.path.join('/home/BERT_nothing/OUTPUT_DIR/', 'prediction.json')
    with open(output_prediction_file, "w") as writer:
        writer.write(json.dumps(dev_predictions, indent=4) + "\n")
    return dev_score


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
n_gpu = torch.cuda.device_count()

logger.info("device: {} n_gpu: {}".format(
    device, n_gpu))

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased', do_lower_case=True)
output_model_file = os.path.join('/home/BERT_nothing/OUTPUT_DIR/pretrained', 'best_BERT_model.bin')
model_state_dict = torch.load(output_model_file, map_location='cpu')
model = BertQA.from_pretrained('bert-base-uncased',
                               state_dict=model_state_dict,
                               allow_yes_no=False)
model.to(device)

predict_file = '/home/BERT_nothing/DATA_DIR/squad-qa/wikipedia-dev.json'
bert_model = 'bert-base-uncased'
max_query_length = 64
test_examples = read_trivia_examples(
    input_file=predict_file,
    is_training=True)


test_features = convert_examples_to_features(
    examples=test_examples,
    tokenizer=tokenizer,
    doc_stride=128,
    max_seq_length=512,
    max_query_length=max_query_length,
    is_training=False
)

model.eval()
all_result = []

predict_batch_size = 12
all_dev_input_ids = torch.tensor([f.input_ids for f in test_features], dtype=torch.long)
all_dev_input_mask = torch.tensor([f.input_mask for f in test_features], dtype=torch.long)
all_dev_segment_ids = torch.tensor([f.segment_ids for f in test_features], dtype=torch.long)
all_dev_example_index = torch.arange(all_dev_input_ids.size(0), dtype=torch.long)
for item in test_features:
    item.question_edge_index[0].append(19)
    item.question_edge_index[1].append(19)
    item.doc_edge_index[0].append(146)
    item.doc_edge_index[1].append(146)
    question_gap = 20 - len(item.question_x)
    doc_gap = 147 - len(item.doc_x)
    for i in range(question_gap):
        item.question_x.append([0, 0])
    for i in range(doc_gap):
        item.doc_x.append([0, 0])
all_dev_question_features = torch.tensor([f.question_x for f in test_features], dtype=torch.float32)
all_dev_doc_features = torch.tensor([f.doc_x for f in test_features], dtype=torch.float32)

dev_data = TensorDataset(all_dev_input_ids, all_dev_input_mask,
                         all_dev_segment_ids, all_dev_example_index,
                         all_dev_question_features, all_dev_doc_features)

dev_sampler = SequentialSampler(dev_data)

dev_graph_question_data = []
dev_graph_doc_data = []
for item in test_features:
    question_g = dgl.graph((item.question_edge_index[0], item.question_edge_index[1]), idtype=torch.int32)
    question_g.ndata['x'] = torch.tensor(item.question_x, dtype=torch.float32)
    question_g = dgl.add_self_loop(question_g)
    doc_g = dgl.graph((item.doc_edge_index[0], item.doc_edge_index[1]), idtype=torch.int32)
    doc_g.ndata['x'] = torch.tensor(item.doc_x, dtype=torch.float32)
    doc_g = dgl.add_self_loop(doc_g)

    dev_graph_question_data.append(question_g)
    dev_graph_doc_data.append(doc_g)

dev_dataloader = DataLoader(dev_data, sampler=dev_sampler,
                            batch_size=predict_batch_size)
dev_question_loader = GraphDataLoader(dev_graph_question_data, batch_size=predict_batch_size)
dev_doc_loader = GraphDataLoader(dev_graph_doc_data, batch_size=predict_batch_size)
dev_evaluator = TriviaEvaluator(test_examples)
best_dev_score = 70.15

best_dev_score = validate_model(model, tokenizer, test_examples, test_features,
                                dev_dataloader, dev_evaluator, best_dev_score, device,dev_question_loader, dev_doc_loader)
print(best_dev_score)


